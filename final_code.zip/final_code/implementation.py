import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from time import time

def models(X_train,Y_train):
        # 1)logistic regression
        from sklearn.linear_model import LogisticRegression
        log=LogisticRegression(random_state=0)
        log.fit(X_train,Y_train)
        
        # 2)KNN
        from sklearn.neighbors import KNeighborsClassifier
        for neighbors in range(1,5):
            knn = KNeighborsClassifier(n_neighbors=neighbors, metric='minkowski')
            knn.fit(X_train, Y_train)
            
        
        # 3)Random Forest
        from sklearn.ensemble import RandomForestClassifier
        for estimators in range(10,30):
            forest=RandomForestClassifier(random_state=0,criterion="entropy",n_estimators=estimators)
            forest.fit(X_train,Y_train)
        
        # 4)Decision Tree
        from sklearn.tree import DecisionTreeClassifier
        for leaves in range(2,15):
            tree = DecisionTreeClassifier(max_leaf_nodes = leaves, random_state=0, criterion='entropy')
            tree.fit(X_train, Y_train)
        
        # 5)Support Vector Machine (SVM)
        from sklearn.svm import SVC
        for c in [0.5,0.6,0.7,0.8,0.9,1.0]:
            svm = SVC(C = c, random_state=0, kernel = 'rbf')
            svm.fit(X_train, Y_train)
        
        
        return log,knn,forest,tree,svm

def random_forest_train():

	# Importing the dataset
	dataset = pd.read_csv('static/dataset/data.csv')
	X = dataset.iloc[:, 2:32].values
	y = dataset.iloc[:, 1].values

	# Encoding categorical data
	from sklearn.preprocessing import LabelEncoder, OneHotEncoder
	labelencoder_X_1 = LabelEncoder()
	y = labelencoder_X_1.fit_transform(y)

	# Splitting the dataset into the Training set and Test set
	global X_test, y_test
	from sklearn.model_selection import train_test_split
	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)


	# Feature Scaling
	from sklearn.preprocessing import StandardScaler
	global sc
	sc = StandardScaler()
	X_train = sc.fit_transform(X_train)
	X_test = sc.transform(X_test)

	model=models(X_train,y_train)
	
	####clf = RandomForestClassifier(n_estimators=100)
	####clf.fit(X_train, y_train)

	clf=model[1]
	return clf

def randorm_forest_test(clf):
	t = time()
	output = clf.predict(X_test)
	acc = accuracy_score(y_test, output) 
	print("The accuracy of testing data: ",acc)
	####print("The running time: ",time()-t)
	return acc

def random_forest_predict(clf, inp):
	t = time()
	inp = sc.transform(inp)
	output = clf.predict(inp)
	####print("The running time: ",time()-t)

	return output;